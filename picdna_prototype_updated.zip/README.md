# PIC-DNA++ Prototype (Simulation)

A small, self-contained Python prototype that **simulates** a progressive image → DNA storage pipeline with **random access** and **progressive layers**. It includes hooks for the novel features suggested in the chat (combinatorial barcoding, UMIs, per-layer ECC knobs, constraint-aware sequence generation, and a simple read-cost model).

> This is **in silico** only — no actual synthesis/sequencing. It aims to help you design, visualize, and compare strategies before wet-lab.

## Key Ideas Implemented

- Progressive "layers" simulated by multi-scale downsampling (L0…L4).
- Separate oligo pools per (image_id, layer_id) with **image primers** and **layer primers** to enable random access (PCR selection) and **thumbnails-first** browse.
- **Combinatorial barcodes** for primers (image barcode × layer barcode) — see `primers.py` — to scale the namespace.
- **UMIs** (8–12 nt) and toy **checksum** to illustrate per-oligo tracking and basic integrity checks (`ecc.py`).
- Simple **constraints** (max homopolymer length, GC range) to keep oligos synthesis-friendly.
- **Error channel** simulator (subs/ins/del) and naive consensus.
- **Read-cost** accounting per equations in the paper, with knobs for coverage per layer.
- Minimal **Streamlit** UI (`streamlit_app.py`) to browse thumbnails, pick target image & layer, and simulate read cost and distortion proxy (MSE).

## Install & Run

```bash
python -m venv .venv && source .venv/bin/activate   # on Windows: .venv\Scripts\activate
pip install -r requirements.txt

# Run CLI simulation
python -m picdna_sim.simulate --images ./sample_images --out ./out --layers 5

# Run the Streamlit UI
streamlit run streamlit_app.py
```

> Put a few PNG/JPG files under `./sample_images` before running. Output DNA "oligo pools" (as FASTA-like) go under `./out`.

## What to tweak first

- **`primers.py`**: set barcode lengths, Hamming distance, and layer primer design policy (combinatorial, orthogonal GC windows, etc.).
- **`ecc.py`**: swap the toy checksum with a real per-oligo ECC (e.g., BCH/LDPC); add per-layer redundancy knobs.
- **`core.py`**: control GC/homopolymer constraints and mapping (`00→A, 01→C, 10→G, 11→T`) or use balanced coders.
- **`simulate.py`**: set coverage by layer, error rates, and cost model. Compare (i) no RA + no progressive, (ii) progressive only, (iii) RA + progressive.

## License

MIT (for your academic use / extension).
